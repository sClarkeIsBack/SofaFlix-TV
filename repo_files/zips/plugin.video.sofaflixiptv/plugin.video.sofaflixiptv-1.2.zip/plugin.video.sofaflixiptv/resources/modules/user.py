import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnNvZmFmbGl4aXB0dg==')

name = b.b64decode('U29mYWZsaXggVHY=')

host = b.b64decode('aHR0cDovL3NvZmFmbGl4aXB0di5kZG5zLm5ldA==')

port = b.b64decode('MjU0NjE=')