import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnNvZmFmbGl4aXB0dg==')

name = b.b64decode('U29mYWZsaXggVHY=')

host = b.b64decode('c29mYWZsaXhpcHR2LmRkbnMubmV0')

port = b.b64decode('MjU0NjE=')